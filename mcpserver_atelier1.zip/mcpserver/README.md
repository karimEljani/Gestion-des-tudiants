# Atelier 1 - Serveur MCP de facturation

Serveur FastMCP (12 tools) qui interroge l'API https://backendfacturation.onrender.com

## Installation (Windows)
```
python -m pip install uv
python -m uv sync
.venv\Scripts\activate
python server.py
```
Serveur MCP : http://127.0.0.1:8001/mcp (port réglable via MCP_PORT dans .env ; 8000 par défaut si absent).
Test : Postman > MCP, ou `python client/test_client.py`.

## Tools (12)
- Articles : getArticleByID, filterArticlesByPriceRange, searchArticles, getArticleRuptureStock, createArticle
- Clients : getClientByID, searchClients, createClient
- Analyse règlements : analyserReglements, detecterAnomalies
- Analyse clients : top_clients_ca, clients_retard_paiement
